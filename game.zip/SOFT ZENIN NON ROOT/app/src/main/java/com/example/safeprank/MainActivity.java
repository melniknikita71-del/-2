package com.example.safeprank;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(13, 16, 30));
        getWindow().setNavigationBarColor(Color.rgb(13, 16, 30));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(32), dp(28), dp(32));
        root.setBackgroundColor(Color.rgb(13, 16, 30));
        setContentView(root);

        TextView title = new TextView(this);
        title.setText("Zenin");
        title.setTextColor(Color.WHITE);
        title.setTextSize(27);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView info = new TextView(this);
        info.setText("Полноэкранное окно будет показано поверх других приложений. Пароль — хуй.");
        info.setTextColor(Color.rgb(190, 199, 220));
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(-1, -2);
        textParams.topMargin = dp(18);
        root.addView(info, textParams);
        Button start = new Button(this);
        start.setText("запуск Zenin");
        start.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(56));
        p.topMargin = dp(24);
        root.addView(start, p);
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Разрешите показ поверх окон, затем вернитесь и нажмите кнопку ещё раз", Toast.LENGTH_LONG).show();
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    Toast.makeText(this, "Не удалось открыть настройки разрешения", Toast.LENGTH_LONG).show();
                }
            } else {
                startService(new Intent(this, OverlayService.class));
                moveTaskToBack(true);
            }
        });
        Button stop = new Button(this);
        stop.setText("Диагностика");
        stop.setAllCaps(false);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(-1, dp(56));
        p2.topMargin = dp(8);
        root.addView(stop, p2);
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
    }
}
